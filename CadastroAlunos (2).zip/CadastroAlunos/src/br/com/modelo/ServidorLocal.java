package br.com.modelo;

import br.com.controle.Alunos;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.*;
import java.lang.reflect.Type;
import java.net.InetSocketAddress;
import java.sql.*;
import java.util.List;

public class ServidorLocal {

    public static void main(String[] args) throws Exception {
        // Cria servidor HTTP na porta 9090
        HttpServer server = HttpServer.create(new InetSocketAddress(9090), 0);
        server.createContext("/importarAlunos", ServidorLocal::handleRequest);
        server.setExecutor(null);
        server.start();
        System.out.println("Servidor rodando em http://localhost:9090/importarAlunos");
    }

    private static void handleRequest(HttpExchange exchange) throws IOException {
        // Permite CORS (somente para teste local)
        exchange.getResponseHeaders().add("Access-Control-Allow-Origin", "*");
        exchange.getResponseHeaders().add("Access-Control-Allow-Methods", "POST, GET, OPTIONS");
        exchange.getResponseHeaders().add("Access-Control-Allow-Headers", "Content-Type");

        // Para requisições OPTIONS do navegador
        if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
            exchange.sendResponseHeaders(204, -1); // No Content
            return;
        }

        if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
            exchange.sendResponseHeaders(405, -1); // Method Not Allowed
            return;
        }

        InputStream is = exchange.getRequestBody();
        String json = new String(is.readAllBytes(), "UTF-8");

        // Converte JSON em lista de alunos
        Gson gson = new Gson();
        Type listType = new TypeToken<List<Alunos>>() {}.getType();
        List<Alunos> alunos = gson.fromJson(json, listType);

        // Salva no MySQL
        String mensagem;
        try {
            salvarNoMySQL(alunos);
            mensagem = "Alunos importados com sucesso!";
        } catch (Exception e) {
            e.printStackTrace();
            mensagem = "Erro: " + e.getMessage();
        }

        exchange.sendResponseHeaders(200, mensagem.getBytes().length);
        OutputStream os = exchange.getResponseBody();
        os.write(mensagem.getBytes());
        os.close();
    }

    private static void salvarNoMySQL(List<Alunos> alunos) throws SQLException {
        String url = "jdbc:mysql://localhost:3306/cadastroalunos"; // seu banco
        String user = "root";
        String password = "catolica"; // sua senha

        Connection con = DriverManager.getConnection(url, user, password);
        String sql = "INSERT INTO alunos (matricula, nome, email) VALUES (?, ?, ?)";
        PreparedStatement ps = con.prepareStatement(sql);

        for (Alunos a : alunos) {
            ps.setInt(1, a.getMatricula());
            ps.setString(2, a.getNome());
            ps.setString(3, a.getEmail());
            ps.executeUpdate();
        }

        ps.close();
        con.close();
    }
}
