/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.modelo;

import br.com.controle.Alunos;
import br.com.modelo.DAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

public class Extrair {
    
    // Recebe os alunos vindos do JS/Frontend (ou de algum endpoint)
    public void salvarNoMySQL(List<Alunos> alunos) {
        DAO dao = new DAO();
        try {
            dao.abrirBanco();
            Connection con = dao.con;

            String sql = "INSERT INTO alunos (matricula, nome, email) VALUES (?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);

            for (Alunos a : alunos) {
                ps.setInt(1, a.getMatricula());
                ps.setString(2, a.getNome());
                ps.setString(3, a.getEmail());
                ps.executeUpdate();
            }

            ps.close();
            dao.fecharBanco();
            System.out.println("Alunos exportados com sucesso!");

        } catch (SQLException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

